'''
    Sensor data grabbing from shield for aws
'''

import greengrasssdk
import platform
from threading import Timer
from cellulariot import cellulariot
import time
import json

node = cellulariot.CellularIoTApp()
node.setupGPIO()




# # Creating a greengrass core sdk client
client = greengrasssdk.client('iot-data')


def greengrass_hello_world_run():
    data = {}
    data['timestamp'] = time.time()
    data['Humidity'] = node.readHum()
    data['Temperature'] = node.readTemp()
    data['Lux'] = node.readLux()
    
    json_data = json.dumps(data)
    print("Sending " + json_data)
    client.publish(
        topic='sensor/data',
        payload=bytes(json_data,encoding="utf-8"))

    # Asynchronously schedule this function to be run again in 5 seconds
    Timer(10, greengrass_hello_world_run).start()


greengrass_hello_world_run()


# This is a dummy handler and will not be invoked
# Instead the code above will be executed in an infinite loop for our example
def function_handler(event, context):
    return